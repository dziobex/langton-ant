# labfinder
Program do znajdowania *ścieżki* w podanym przez użytkownika labiryncie.

# Sposób użycia